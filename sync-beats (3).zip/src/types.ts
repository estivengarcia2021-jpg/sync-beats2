/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RoomState {
  roomId: string;
  hostId: string;
  currentTrackId: string | null;
  trackStartTime: number | null; // UTC timestamp em milissegundos
  status: 'playing' | 'paused';
  seekPosition: number; // Posição atual em milissegundos se pausado
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: number;
}

export interface Reaction {
  id: string;
  emoji: string;
  x: number;
  y: number;
  timestamp: number;
}

export interface Suggestion {
  id: string;
  title: string;
  artist: string;
  userId: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface SyncPlayPayload {
  trackId: string;
  startTime: number; // UTC timestamp
  seekPosition: number;
}


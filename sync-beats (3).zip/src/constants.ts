export interface Track {
  id: string;
  title: string;
  artist: string;
  coverUrl: string;
  genre: string;
}

export const MOCK_TRACKS: Track[] = [
  {
    id: "midnight-city",
    title: "Midnight City",
    artist: "M83",
    coverUrl: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "Indie Electronic"
  },
  {
    id: "starboy",
    title: "Starboy",
    artist: "The Weeknd",
    coverUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "R&B / Pop"
  },
  {
    id: "blinding-lights",
    title: "Blinding Lights",
    artist: "The Weeknd",
    coverUrl: "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "Synthwave"
  },
  {
    id: "stay",
    title: "Stay",
    artist: "The Kid LAROI & Justin Bieber",
    coverUrl: "https://images.unsplash.com/photo-1459749411177-042180ce673c?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "Pop"
  },
  {
    id: "drivers-license",
    title: "Drivers License",
    artist: "Olivia Rodrigo",
    coverUrl: "https://images.unsplash.com/photo-1514525253361-bee87184919a?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "Pop Rock"
  },
  {
    id: "heat-waves",
    title: "Heat Waves",
    artist: "Glass Animals",
    coverUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=300&h=300&auto=format&fit=crop",
    genre: "Indie Pop"
  }
];
